export interface User {
    user:  string;
    email: string;
    password: string;
}