import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChampsRoutingModule } from './champs-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ChampsRoutingModule
  ]
})
export class ChampsModule { }
